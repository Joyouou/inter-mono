Inter Mono 1.400
================

A monospaced adaptation of Inter, for code and terminals. Regular and Italic.

This is an unofficial derivative. It is not made or endorsed by the Inter project.

Install
-------
macOS:    open each .ttf in the ttf folder and choose Install Font.
Windows:  right-click each .ttf and choose Install.
Linux:    copy the .ttf files to ~/.local/share/fonts and run fc-cache.

Then pick "Inter Mono" in your editor or terminal.
The webfonts folder holds .woff2 files for websites.

Credits
-------
Inter is designed by Rasmus Andersson and The Inter Project Authors.
All letter shapes come from Inter. "Inter" is a trademark of Rasmus Andersson.
The monospaced adaptation was designed and built by Claude, an AI model made
by Anthropic.

Licence
-------
SIL Open Font License 1.1, see OFL.txt. Free to use, change and share,
including commercially. Not to be sold by itself.
