Inter Mono 1.611
================

A monospaced adaptation of Inter, for code and terminals. Regular and Italic.

This is an unofficial derivative. It is not made or endorsed by the Inter project.

Install
-------
macOS:    open each .ttf in the ttf folder and choose Install Font.
Windows:  right-click each .ttf and choose Install.
Linux:    copy the .ttf files to ~/.local/share/fonts and run fc-cache.

Then pick "Inter Mono" in your editor or terminal.
The webfonts folder holds .woff2 files for websites.

Caption version
---------------
The caption folder holds Inter Mono Caption, a colour font for the look of
television closed captions: every character sits on an opaque black box.
Inter Mono Caption 75, 50 and 25 have a see-through box (75, 50 or 25 percent
opaque). Use those at a size that is a multiple of 5 px (20, 25, 30 ...), so
the boxes join without lines between them.
New in 1.600: the music notes ♩ ♪ ♫ ♬. New in 1.610: ☎ and ⌁. 1.611: no clipping on Windows.
The letters take the text colour you set; with black text they are invisible,
so set a colour (white, yellow, cyan). Use the default line height. It needs
a program that supports colour fonts (COLR); others show plain letters.

Credits
-------
Inter is designed by Rasmus Andersson and The Inter Project Authors.
All letter shapes come from Inter. "Inter" is a trademark of Rasmus Andersson.
The monospaced adaptation was designed and built by Claude, an AI model made
by Anthropic.

Licence
-------
SIL Open Font License 1.1, see OFL.txt. Free to use, change and share,
including commercially. Not to be sold by itself.
